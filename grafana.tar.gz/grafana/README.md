# Monitoring stack for Umee

## Description
This Monitoring stack is made of :
- grafana for the viewing of the graph
- node_exporter to monitor your host
- prometheus to capture the metrics and make it available for Grafana
- loki/promtail to view the system and umee logs on your grafana

## Prereq

For this to work, please do a one off install of docker and the loki driver

```bash
# install docker / docker-compose
sudo apt update
sudo apt install -y ca-certificates curl gnupg lsb-release
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu \
  $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
sudo apt update
sudo apt install -y docker-compose docker-ce docker-ce-cli containerd.io
sudo usermod -aG docker $USER #you need to logout and login back after that
# install the loki driver
docker plugin install grafana/loki-docker-driver:latest --alias loki --grant-all-permissions
```

## Installing the stack

### update start.sh
There is a need to do some minimum configuration in order to have it ready
- update the admin/password of your grafana
- the telegram information, you can create your telegram bot following this : <https://core.telegram.org/bots#6-botfather> and obtain the chat_id <https://stackoverflow.com/a/32572159>

### start the stack
```bash
bash start.sh
```
